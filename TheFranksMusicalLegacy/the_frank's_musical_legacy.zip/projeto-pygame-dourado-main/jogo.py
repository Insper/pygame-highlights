from classe_jogo import Jogo


j = Jogo()
Jogo.atual = j
j.game_loop()